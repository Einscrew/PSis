#ifndef UTILS
#define UTILS

void * mallocV(int size, char * msg);

#endif