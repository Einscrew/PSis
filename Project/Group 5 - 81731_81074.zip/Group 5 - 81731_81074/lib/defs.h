#ifndef defsHeader
#define defsHeader

typedef void * Item;

#endif